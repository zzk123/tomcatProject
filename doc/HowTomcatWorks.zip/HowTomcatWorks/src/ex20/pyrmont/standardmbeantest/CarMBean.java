package ex20.pyrmont.standardmbeantest;
public interface CarMBean {

  public String getColor();
  public void setColor(String color);
  public void drive();

}
